// Cart functionality
let cart = [];
const cartCount = document.getElementById('cart-count');
const cartItemsContainer = document.getElementById('cart-items');
const emptyCartMessage = document.getElementById('empty-cart-message');
const cartSubtotal = document.getElementById('cart-subtotal');
const cartDelivery = document.getElementById('cart-delivery');
const cartTotal = document.getElementById('cart-total');
const proceedToCheckout = document.getElementById('proceed-to-checkout');

// DOM Elements
const mobileMenuButton = document.getElementById('mobile-menu-button');
const closeMobileMenu = document.getElementById('close-mobile-menu');
const mobileMenu = document.getElementById('mobile-menu');
const overlay = document.getElementById('overlay');
const cartButton = document.getElementById('cart-button');
const closeCart = document.getElementById('close-cart');
const continueShopping = document.getElementById('continue-shopping');
const cartSidebar = document.getElementById('cart-sidebar');
const loginButton = document.getElementById('login-button');
const mobileLoginButton = document.getElementById('mobile-login-button');
const closeLoginModal = document.getElementById('close-login-modal');
const loginModal = document.getElementById('login-modal');
const loginForm = document.getElementById('login-form');
const loginError = document.getElementById('login-error');
const checkoutModal = document.getElementById('checkout-modal');
const closeCheckoutModal = document.getElementById('close-checkout-modal');
const checkoutForm = document.getElementById('checkout-form');
const paymentMethods = document.querySelectorAll('input[name="payment-method"]');
const cardDetails = document.getElementById('card-details');

// Calculate delivery fee (free for orders over ₹500)
function calculateDelivery(subtotal) {
    return subtotal > 500 ? 0 : 50;
}

// Update cart totals
function updateCartTotals() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const delivery = calculateDelivery(subtotal);
    const total = subtotal + delivery;
    
    cartSubtotal.textContent = `₹${subtotal.toFixed(2)}`;
    cartDelivery.textContent = `₹${delivery.toFixed(2)}`;
    cartTotal.textContent = `₹${total.toFixed(2)}`;
    
    // Update checkout totals if checkout modal is open
    if (checkoutModal.classList.contains('open')) {
        document.getElementById('checkout-subtotal').textContent = `₹${subtotal.toFixed(2)}`;
        document.getElementById('checkout-delivery').textContent = `₹${delivery.toFixed(2)}`;
        document.getElementById('checkout-total').textContent = `₹${total.toFixed(2)}`;
    }
    
    // Update cart count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    
    // Show/hide empty cart message
    if (cart.length === 0) {
        emptyCartMessage.style.display = 'block';
        proceedToCheckout.disabled = true;
        proceedToCheckout.classList.add('opacity-50', 'cursor-not-allowed');
    } else {
        emptyCartMessage.style.display = 'none';
        proceedToCheckout.disabled = false;
        proceedToCheckout.classList.remove('opacity-50', 'cursor-not-allowed');
    }
}

// Render cart items
function renderCartItems() {
    cartItemsContainer.innerHTML = '';
    
    cart.forEach((item, index) => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item flex items-center p-3 border border-gray-200 rounded-lg transition duration-300';
        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.name} thumbnail for cart item" class="w-16 h-16 object-cover rounded-md mr-4">
            <div class="flex-1">
                <h3 class="font-medium">${item.name}</h3>
                <p class="text-sm text-gray-500">1 kg</p>
                <div class="flex justify-between items-center mt-1">
                    <span class="font-bold text-green-600">₹${(item.price * item.quantity).toFixed(2)}</span>
                    <div class="flex items-center">
                        <button class="decrease-quantity px-2 py-1 bg-gray-100 text-gray-600 rounded-l" data-index="${index}">-</button>
                        <span class="px-3 bg-gray-50">${item.quantity}</span>
                        <button class="increase-quantity px-2 py-1 bg-gray-100 text-gray-600 rounded-r" data-index="${index}">+</button>
                    </div>
                </div>
            </div>
            <button class="remove-item text-gray-400 hover:text-red-500 ml-2" data-index="${index}">
                <i class="fas fa-trash"></i>
            </button>
        `;
        cartItemsContainer.appendChild(cartItem);
    });
    
    // Add event listeners to new buttons
    document.querySelectorAll('.decrease-quantity').forEach(button => {
        button.addEventListener('click', (e) => {
            const index = e.target.getAttribute('data-index');
            if (cart[index].quantity > 1) {
                cart[index].quantity--;
            } else {
                cart.splice(index, 1);
            }
            renderCartItems();
            updateCartTotals();
        });
    });
    
    document.querySelectorAll('.increase-quantity').forEach(button => {
        button.addEventListener('click', (e) => {
            const index = e.target.getAttribute('data-index');
            cart[index].quantity++;
            renderCartItems();
            updateCartTotals();
        });
    });
    
    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', (e) => {
            const index = e.target.getAttribute('data-index');
            cart.splice(index, 1);
            renderCartItems();
            updateCartTotals();
        });
    });
}

// Add to cart functionality
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        
        const productId = button.getAttribute('data-product-id');
        const productName = button.getAttribute('data-product-name');
        const productPrice = parseFloat(button.getAttribute('data-product-price'));
        const productImage = button.getAttribute('data-product-image');
        
        // Check if product already in cart
        const existingItem = cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({
                id: productId,
                name: productName,
                price: productPrice,
                image: productImage,
                quantity: 1
            });
        }
        
        // Update cart UI
        renderCartItems();
        updateCartTotals();
        
        // Animate cart button
        cartCount.classList.add('cart-item-added');
        setTimeout(() => {
            cartCount.classList.remove('cart-item-added');
        }, 500);
        
        // Open cart sidebar if not already open
        if (!cartSidebar.classList.contains('open')) {
            toggleCart();
        }
    });
});

// Mobile menu functionality
function toggleMobileMenu() {
    mobileMenu.classList.toggle('open');
    overlay.classList.toggle('open');
    document.body.style.overflow = mobileMenu.classList.contains('open') ? 'hidden' : '';
}

mobileMenuButton.addEventListener('click', toggleMobileMenu);
closeMobileMenu.addEventListener('click', toggleMobileMenu);
overlay.addEventListener('click', () => {
    if (mobileMenu.classList.contains('open')) {
        toggleMobileMenu();
    }
});

// Cart sidebar functionality
function toggleCart() {
    cartSidebar.classList.toggle('open');
    overlay.classList.toggle('open');
    document.body.style.overflow = cartSidebar.classList.contains('open') ? 'hidden' : '';
}

cartButton.addEventListener('click', toggleCart);
closeCart.addEventListener('click', toggleCart);
continueShopping.addEventListener('click', toggleCart);
overlay.addEventListener('click', () => {
    if (cartSidebar.classList.contains('open')) {
        toggleCart();
    }
});

// Login modal functionality
function toggleLoginModal() {
    loginModal.classList.toggle('open');
    overlay.classList.toggle('open');
    document.body.style.overflow = loginModal.classList.contains('open') ? 'hidden' : '';
    
    // Close mobile menu if open
    if (mobileMenu.classList.contains('open')) {
        toggleMobileMenu();
    }
}

loginButton.addEventListener('click', toggleLoginModal);
mobileLoginButton.addEventListener('click', toggleLoginModal);
closeLoginModal.addEventListener('click', toggleLoginModal);
overlay.addEventListener('click', () => {
    if (loginModal.classList.contains('open')) {
        toggleLoginModal();
    }
});

// Login form submission
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    // Simple validation (in a real app, this would be a server-side check)
    if (email === 'user@example.com' && password === 'password') {
        // Successful login
        loginError.style.display = 'none';
        alert('Login successful!');
        toggleLoginModal();
    } else {
        // Show error
        loginError.style.display = 'block';
    }
});

// Checkout functionality
function toggleCheckoutModal() {
    if (cart.length === 0) {
        alert('Your cart is empty. Please add items before checkout.');
        return;
    }
    
    // Update checkout totals
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const delivery = calculateDelivery(subtotal);
    const total = subtotal + delivery;
    
    document.getElementById('checkout-subtotal').textContent = `₹${subtotal.toFixed(2)}`;
    document.getElementById('checkout-delivery').textContent = `₹${delivery.toFixed(2)}`;
    document.getElementById('checkout-total').textContent = `₹${total.toFixed(2)}`;
    
    checkoutModal.classList.toggle('open');
    overlay.classList.toggle('open');
    document.body.style.overflow = checkoutModal.classList.contains('open') ? 'hidden' : '';
}

// Payment method toggle
paymentMethods.forEach(method => {
    method.addEventListener('change', (e) => {
        if (e.target.value === 'card') {
            cardDetails.classList.remove('hidden');
        } else {
            cardDetails.classList.add('hidden');
        }
    });
});

// Form submission
checkoutForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    // Validate required fields
    const name = document.getElementById('checkout-name').value;
    const email = document.getElementById('checkout-email').value;
    const address = document.getElementById('checkout-address').value;
    const phone = document.getElementById('checkout-phone').value;
    
    if (!name || !email || !address || !phone) {
        alert('Please fill in all required fields');
        return;
    }
    
    // Validate card details if card payment selected
    const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
    
    if (paymentMethod === 'card') {
        const cardNumber = document.getElementById('card-number').value;
        const expiryDate = document.getElementById('expiry-date').value;
        const cvv = document.getElementById('cvv').value;
        const cardName = document.getElementById('card-name').value;
        
        if (!cardNumber || !expiryDate || !cvv || !cardName) {
            alert('Please enter all card details');
            return;
        }
        
        // Simple card number validation
        if (!/^\d{16}$/.test(cardNumber.replace(/\s/g, ''))) {
            alert('Please enter a valid 16-digit card number');
            return;
        }
        
        // Simple expiry date validation
        if (!/^\d{2}\/\d{2}$/.test(expiryDate)) {
            alert('Please enter expiry date in MM/YY format');
            return;
        }
        
        // Simple CVV validation
        if (!/^\d{3,4}$/.test(cvv)) {
            alert('Please enter a valid 3 or 4-digit CVV');
            return;
        }
    }
    
    // In a real app, you would process the payment here
    alert(`Order placed successfully!\n\nDelivery to: ${address}\n\nTotal: ${document.getElementById('checkout-total').textContent}\n\nThank you for your purchase!`);
    
    // Clear cart and close modals
    cart = [];
    renderCartItems();
    updateCartTotals();
    toggleCheckoutModal();
    toggleCart();
    
    // Reset form
    checkoutForm.reset();
    cardDetails.classList.add('hidden');
});

// Event listeners
proceedToCheckout.addEventListener('click', toggleCheckoutModal);
closeCheckoutModal.addEventListener('click', toggleCheckoutModal);
overlay.addEventListener('click', () => {
    if (checkoutModal.classList.contains('open')) {
        toggleCheckoutModal();
    }
});

// Close modals when pressing Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        if (loginModal.classList.contains('open')) {
            toggleLoginModal();
        } else if (cartSidebar.classList.contains('open')) {
            toggleCart();
        } else if (mobileMenu.classList.contains('open')) {
            toggleMobileMenu();
        } else if (checkoutModal.classList.contains('open')) {
            toggleCheckoutModal();
        }
    }
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth'
            });
            
            // Close mobile menu if open
            if (mobileMenu.classList.contains('open')) {
                toggleMobileMenu();
            }
        }
    });
});

// Initialize cart
updateCartTotals();




