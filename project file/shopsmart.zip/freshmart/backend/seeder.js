const products = [
  {
    name: "Fresh Apples",
    category: "Fruits",
    price: 2.5,
    image: "https://www.orgpick.com/cdn/shop/articles/Apple_1024x1024.jpg?v=1547124407",
    description: "Fresh and crispy apples"
  },
  {
    name: "Carrots",
    category: "Vegetables",
    price: 1.2,
    image: "https://www.orgpick.com/cdn/shop/articles/Carrot_1024x1024.jpg?v=1547124407",
    description: "Healthy organic carrots"
  },
  {
    name: "Milk",
    category: "Dairy",
    price: 3,
    image: "https://www.orgpick.com/cdn/shop/articles/Milk_1024x1024.jpg?v=1547124407",
    description: "Pure cow milk"
  }
];
