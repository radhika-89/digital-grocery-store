const express = require('express');
const router = express.Router(); // ✅ THIS LINE WAS MISSING

// Your login route
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  // Dummy auth logic (replace with real user lookup)
  if (email === 'hrudayr16@gmail.com' && password === 'password123') {
    return res.json({ token: 'dummy-jwt-token' });
  }

  return res.status(401).json({ error: 'Invalid credentials' });
});

module.exports = router;
