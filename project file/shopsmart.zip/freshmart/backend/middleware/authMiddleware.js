// Middleware logic here
