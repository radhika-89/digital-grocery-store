// cart.js - This should be included in all pages

let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Update cart in localStorage
function updateCartStorage() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Calculate delivery fee
function calculateDelivery(subtotal) {
    return subtotal > 500 ? 0 : 50;
}

// Update cart totals display
function updateCartTotals() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const delivery = calculateDelivery(subtotal);
    const total = subtotal + delivery;
    
    // Update elements if they exist on the page
    if (document.getElementById('cart-subtotal')) {
        document.getElementById('cart-subtotal').textContent = `₹${subtotal.toFixed(2)}`;
    }
    if (document.getElementById('cart-delivery')) {
        document.getElementById('cart-delivery').textContent = `₹${delivery.toFixed(2)}`;
    }
    if (document.getElementById('cart-total')) {
        document.getElementById('cart-total').textContent = `₹${total.toFixed(2)}`;
    }
    
    // Update cart count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    if (document.getElementById('cart-count')) {
        document.getElementById('cart-count').textContent = totalItems;
    }
}

// Add item to cart
function addToCart(productId, productName, productPrice, productImage) {
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({
            id: productId,
            name: productName,
            price: productPrice,
            image: productImage,
            quantity: 1
        });
    }
    
    updateCartStorage();
    updateCartTotals();
    
    // Animate cart button
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        cartCount.classList.add('cart-item-added');
        setTimeout(() => {
            cartCount.classList.remove('cart-item-added');
        }, 500);
    }
}

// Remove item from cart
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartStorage();
    updateCartTotals();
}

// Adjust item quantity
function adjustQuantity(index, change) {
    cart[index].quantity += change;
    
    if (cart[index].quantity < 1) {
        cart.splice(index, 1);
    }
    
    updateCartStorage();
    updateCartTotals();
}

// Initialize cart on page load
document.addEventListener('DOMContentLoaded', () => {
    updateCartTotals();
    
    // Add event listeners for all add-to-cart buttons
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const productId = button.getAttribute('data-product-id');
            const productName = button.getAttribute('data-product-name');
            const productPrice = parseFloat(button.getAttribute('data-product-price'));
            const productImage = button.getAttribute('data-product-image');
            
            addToCart(productId, productName, productPrice, productImage);
        });
    });
});